/*
 * Copyright 2015 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.ece420.lab3;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioRecord;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Handler;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;
import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;


public class MainActivity extends Activity
        implements ActivityCompat.OnRequestPermissionsResultCallback {

    // UI Variables
    String  nativeSampleRate;
    String  nativeSampleBufSize;
    boolean supportRecording;
    Boolean isPlaying = false;
    ImageView stftView;
    Bitmap bitmap;
    Canvas canvas;
    Paint paint;
    // Static Values
    private static final int AUDIO_ECHO_REQUEST = 0;
    private static final int FRAME_SIZE = 1024;
    private static final int BITMAP_HEIGHT = 500;
    private static final String TAG = "MainActivity";

    private Button convertButton;
    private TextView morse_output;
    private List<Integer> morseData = new ArrayList<Integer>();

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setContentView(R.layout.activity_main);
        super.setRequestedOrientation (ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);

        // Google NDK Stuff
        queryNativeAudioParameters();
        // initialize native audio system
        updateNativeAudioUI();
        if (supportRecording) {
            // Change audio sampling rate and frame size
            createSLEngine(Integer.parseInt(nativeSampleRate), FRAME_SIZE);
        }

        // UI Variables and Setup
        stftView = (ImageView) this.findViewById(R.id.stftView);
        bitmap =  Bitmap.createBitmap((FRAME_SIZE), BITMAP_HEIGHT, Bitmap.Config.ARGB_8888);
        canvas = new Canvas(bitmap);
        canvas.drawColor(Color.BLACK);
        paint = new Paint();
        paint.setColor(Color.GREEN);
        paint.setStyle(Paint.Style.FILL);
        stftView.setImageBitmap(bitmap);
        initializeStftBackgroundThread(10);
        convertButton = (Button) findViewById(R.id.convertBtn);
        morse_output = (TextView) findViewById(R.id.morseOutput);
        // Setup Switch for choosing model, True = tf SVM model, False = regular SVM model

        // Copied from OnClick handler
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) !=
                PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                    this,
                    new String[] { Manifest.permission.RECORD_AUDIO },
                    AUDIO_ECHO_REQUEST);
            return;
        }
        convertButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                convert();
            }
        });
        startEcho();

    }
    @Override
    protected void onDestroy() {
        if (supportRecording) {
            if (isPlaying) {
                stopPlay();
            }
            deleteSLEngine();
            isPlaying = false;
        }
        super.onDestroy();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    private void startEcho() {
        if(!supportRecording){
            return;
        }
        if (!isPlaying) {
            if(!createSLBufferQueueAudioPlayer()) {
                return;
            }
            if(!createAudioRecorder()) {
                deleteSLBufferQueueAudioPlayer();
                return;
            }
            startPlay();   // this must include startRecording()
        } else {
            stopPlay();  //this must include stopRecording()
            updateNativeAudioUI();
            deleteAudioRecorder();
            deleteSLBufferQueueAudioPlayer();
        }
        isPlaying = !isPlaying;
    }

    public void onEchoClick(View view) {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) !=
                PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                    this,
                    new String[] { Manifest.permission.RECORD_AUDIO },
                    AUDIO_ECHO_REQUEST);
            return;
        }
        startEcho();
    }

    public void getLowLatencyParameters(View view) {
        updateNativeAudioUI();
        return;
    }

    private void queryNativeAudioParameters() {
        AudioManager myAudioMgr = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        nativeSampleRate  =  myAudioMgr.getProperty(AudioManager.PROPERTY_OUTPUT_SAMPLE_RATE);
        nativeSampleBufSize =myAudioMgr.getProperty(AudioManager.PROPERTY_OUTPUT_FRAMES_PER_BUFFER);
        int recBufSize = AudioRecord.getMinBufferSize(
                Integer.parseInt(nativeSampleRate),
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT);
        supportRecording = true;
        if (recBufSize == AudioRecord.ERROR ||
                recBufSize == AudioRecord.ERROR_BAD_VALUE) {
            supportRecording = false;
        }
    }
    private void updateNativeAudioUI() {
        if (!supportRecording) {
            return;
        }


    }
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        /*
         * if any permission failed, the sample could not play
         */
        if (AUDIO_ECHO_REQUEST != requestCode) {
            super.onRequestPermissionsResult(requestCode, permissions, grantResults);
            return;
        }

        if (grantResults.length != 1  ||
                grantResults[0] != PackageManager.PERMISSION_GRANTED) {
            /*
             * When user denied permission, throw a Toast to prompt that RECORD_AUDIO
             * is necessary; also display the status on UI
             * Then application goes back to the original state: it behaves as if the button
             * was not clicked. The assumption is that user will re-click the "start" button
             * (to retry), or shutdown the app in normal way.
             */
            Toast.makeText(getApplicationContext(),
                    getString(R.string.prompt_permission),
                    Toast.LENGTH_SHORT).show();
            return;
        }

        /*
         * When permissions are granted, we prompt the user the status. User would
         * re-try the "start" button to perform the normal operation. This saves us the extra
         * logic in code for async processing of the button listener.
         */

        // The callback runs on app's thread, so we are safe to resume the action
        startEcho();
    }

    // All this does is calls the UpdateStftTask at a fixed interval
    // http://stackoverflow.com/questions/6531950/how-to-execute-async-task-repeatedly-after-fixed-time-intervals
    public void initializeStftBackgroundThread(int timeInMs) {
        final Handler handler = new Handler();
        Timer timer = new Timer();
        TimerTask doAsynchronousTask = new TimerTask() {
            @Override
            public void run() {
                handler.post(new Runnable() {
                    public void run() {
                        try {
                            UpdateStftTask performStftUiUpdate = new UpdateStftTask();
                            performStftUiUpdate.execute();
                        } catch (Exception e) {
                            // TODO Auto-generated catch block
                        }
                    }
                });
            }
        };
        timer.schedule(doAsynchronousTask, 0, timeInMs); // execute every 10 ms
    }
    //FUNCTION THAT WAS NECESSARY TO IMPLEMENT
    //Buffer for getting data. Needed to find a way to find out the sampling rate of the tablet
    //SO that the morseData is not a full of garbage 1s and 0s.
    //finding first buffer with noise roughly ha;fway in buffer. Find last buffer that noise is detected
    //Time of how many buffers are active determine the morse (dit or dah)

    //Create a continuous string for the first step of morse conversion
    //Dits and dahs created after detecting units of sound/silence
    //Slashes seperate words, commas seperate single characters. These can later be split for
    //mapping the dits and dahs to English
    public String getChars(List<Integer> morseData) {
        StringBuilder charMorse = new StringBuilder();
        int i = 0;
        int unit_silence = 0; // silence, will count zeroes in data
        int unit_sound = 0; // sound, will count ones in data
        while (i < morseData.size()) {
            if (morseData.get(i) == 1) {
                if (unit_silence > 6) {
                    charMorse.append("/"); // 7 zeroes in a row means a space.
                    unit_silence = 0;
                    unit_sound = 0;
                } else if (unit_silence > 2) { // 3 zeroes in a row means a new character.
                    charMorse.append(",");
                    unit_silence = 0;
                    unit_sound = 0;
                } else {
                    unit_silence = 0; //base no silence, then update sound
                }
                unit_sound++;
            } else {
                if (unit_sound > 2) {
                    charMorse.append("-"); // 3 ones in a row means a dah.
                    unit_sound = 0;
                    unit_silence = 0;
                } else if (unit_sound > 0) {
                    charMorse.append("."); // 1 one means a dit.
                    unit_sound = 0;
                    unit_silence = 0;
                } else {
                    unit_sound = 0; //base with no sound, then update silence
                }
                unit_silence++;
            }
            i++;
        }
        //System.out.println(charMorse.toString());
        return charMorse.toString();
    }
    //Decode function with input of continuous string
    //Create an array of words, add words by using split by slashes
    //Create an array list for individual letters
    //Letters are mapped to their English representation
    public String decode(String message) {
        String[] words = message.split("/");
        List<List<String>> letters = new ArrayList<>();

        for (String word : words) {
            List<String> letterList = new ArrayList<>();
            for (String keycode : word.split(",")) {
                try {
                    letterList.add(String.valueOf(Map.morseMap.get(keycode)));
                } catch (NullPointerException e) {
                    letterList.add("?");
                }
            }
            letters.add(letterList);
        }

        StringBuilder morse = new StringBuilder();
        for (List<String> letter : letters) {
            for (String code : letter) {
                morse.append(code);
            }
            morse.append(" ");
        }
        //System.out.println(morse.toString());
        return morse.toString();
    }
    //Main function for full conversion
    //Get chars from morseData recorded as time goes on
    //morseData converted to long string of dits and dahs
    //String of morse split and converted to English
    //Set textView to conversion
    public void convert() {
        try {
            String chars = getChars(morseData);
            String morse = decode(chars);
            morse_output.setText(morse);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    // UI update
    private class UpdateStftTask extends AsyncTask<Void, FloatBuffer, Void> {
        @Override
        protected Void doInBackground(Void... params) {

            // Float == 4 bytes
            // Note: We're using FloatBuffer instead of float array because interfacing with JNI
            // with a FloatBuffer allows direct memory sharing, versus having to copy to some
            // intermediate location first.
            // http://stackoverflow.com/questions/10697161/why-floatbuffer-instead-of-float
            FloatBuffer buffer = ByteBuffer.allocateDirect(FRAME_SIZE * 4)
                    .order(ByteOrder.LITTLE_ENDIAN)
                    .asFloatBuffer();

            getFftBuffer(buffer);

            // Update screen, needs to be done on UI thread
            publishProgress(buffer);
            return null;
        }

        protected void onProgressUpdate(FloatBuffer... newDisplayUpdate) {
            int r = 0;int g = 0;int b = 0;

            // emulates a scrolling window
            Rect srcRect = new Rect(0, -(-1), bitmap.getWidth(), bitmap.getHeight());
            Rect destRect = new Rect(srcRect);
            destRect.offset(0, -1);
            canvas.drawBitmap(bitmap, srcRect, destRect, null);

            // update latest column with new values which need to be between 0.0 and 1.0
            for(int i=0;i < newDisplayUpdate[0].capacity();i++) {
                double val = newDisplayUpdate[0].get();

                // simple linear RYGCB colormap
                if(val <= 0.9) {
                    g = 255;
                    b = 0;
                    r = 0;
                    morseData.add(0);

                }  if(val >= 0.9) {
                    g = 0;
                    b = 0;
                    r = 255;
                    morseData.add(1);

                }

                // set color with constant alpha
                paint.setColor(Color.argb(255, r, g, b));
                // paint corresponding area
                canvas.drawRect(i, BITMAP_HEIGHT-1, i+1, BITMAP_HEIGHT, paint);
            }
            newDisplayUpdate[0].rewind();
            stftView.invalidate();
        }
    }

    /*
     * Loading our Libs
     */
    static {
        System.loadLibrary("echo");
    }

    /*
     * jni function implementations...
     */
    public static native void createSLEngine(int rate, int framesPerBuf);
    public static native void deleteSLEngine();

    public static native boolean createSLBufferQueueAudioPlayer();
    public static native void deleteSLBufferQueueAudioPlayer();

    public static native boolean createAudioRecorder();
    public static native void deleteAudioRecorder();
    public static native void startPlay();
    public static native void stopPlay();

    public static native void getFftBuffer(FloatBuffer buffer);
}
